let Cotacao = document.querySelector("#Cotacao");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
    let num1 = Number(Cotacao.value)

    let aumento1 = (num1 * 1.01)
    let aumento2 = (num1 * 1.02)
    let aumento5 = (num1 * 1.05)
    let aumento10 = (num1 * 1.10)
    
    Resultado.innerHTML = "Aumento de 1%:" + aumento1 + "<br>" + 
    "Aumento de 2%:" + aumento2 + "<br>" + 
    "Aumento de 5%:" + aumento5 + "<br>" + 
    "Aumento de 10%:" + aumento10;
}

btCalcular.onclick = function() {
    Calcular();
}